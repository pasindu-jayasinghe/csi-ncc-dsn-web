import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parameter-location-data',
  templateUrl: './parameter-location-data.component.html',
  styleUrls: ['./parameter-location-data.component.scss']
})
export class ParameterLocationDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
