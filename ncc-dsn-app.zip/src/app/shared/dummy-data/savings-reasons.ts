export const SavingsReasons = [
  {
    name: 'Just invest',
    id: '1',
    selected: true,
  },
  {
    name: 'Rainy day ',
    id: '2',
    selected: false,
  },
  {
    name: 'House',
    id: '3',
    selected: false,
  },
  {
    name: 'Retirement',
    id: '4',
    selected: false,
  },
  {
    name: 'Childrens education expenses',
    id: '5',
    selected: false,
  },
  {
    name: 'Big spend',
    id: '6',
    selected: false,
  },
];
