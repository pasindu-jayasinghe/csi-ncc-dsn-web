import { NumericTextDirective } from './numeric-text.directive';

describe('NumericTextDirective', () => {
  it('should create an instance', () => {
    const directive = new NumericTextDirective();
    expect(directive).toBeTruthy();
  });
});
