export const environment = {
  production: true,
  baseUrlAPI: 'http://40.65.186.12:7080',  
  baseUrlAPIDocUploadAPI: 'http://40.65.186.12:7080/document/upload2'  

  //baseUrlAPI: " https://e50d4ab4906f.ngrok.io"
};
