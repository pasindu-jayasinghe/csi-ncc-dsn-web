export const environment = {
  production: true,
  // baseUrlAPI: 'http://13.76.166.4:7080',  
  baseUrlAPI: 'http://nccdsn.climatesi.com:7080',  
  //ec2-3-7-54-14.ap-south-1.compute.amazonaws.com
  //baseUrlAPIDocUploadAPI: 'http://13.76.166.4:7080/document/upload2',
  baseUrlAPIDocUploadAPI: 'http://nccdsn.climatesi.com:7080/document/upload2',

  //baseUrlAPI: " https://e50d4ab4906f.ngrok.io"

  keycloak : {
    // Url of the Identity Provider
    // issuer : "http://13.76.166.4:8080/auth/realms/ncc-dsn",
    issuer : "http://nccdsn.climatesi.com:8080/auth/realms/ncc-dsn",
    // URL of the SPA to redirect the user to after login
    // redirectUri : "http://13.76.166.4:7070",
    redirectUri : "http://nccdsn.climatesi.com:7070",
    //redirectUri : "http://40.65.186.12:7070",
    //http://40.65.186.12:7070/home
    // The SPA's id. 
    // The SPA is registerd with this id at the auth-serverß
    clientId: "dsn-app",
    responseType : "code",
    // set the scope for the permissions the client should request
    // The first three are defined by OIDC.
    scope : "openid profile email",
    requireHttps:"",
    showDebugInformation : "",
    disableAtHashCheck : "",
  }

};
